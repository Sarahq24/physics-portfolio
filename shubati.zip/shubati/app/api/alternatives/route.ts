import { prisma, ready } from "@/lib/db";
import { findAlternatives } from "@/lib/alternatives";
export const dynamic = "force-dynamic";
export async function GET(req: Request) {
  await ready();
  const u = new URL(req.url);
  const id = u.searchParams.get("id") ?? "";
  const ids = (u.searchParams.get("schedule") ?? "").split(",").filter(Boolean);
  const all = await prisma.section.findMany();
  const target = all.find((s) => s.id === id);
  if (!target) return Response.json([], { status: 404 });
  return Response.json(findAlternatives(target, all, all.filter((s) => ids.includes(s.id))));
}
