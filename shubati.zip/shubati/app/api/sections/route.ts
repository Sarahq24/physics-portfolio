import { prisma, ready } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function GET() {
  await ready();
  return Response.json(await prisma.section.findMany({ orderBy: { id: "asc" } }));
}
