import { prisma, ready } from "@/lib/db";
export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  await ready();
  const { sectionId } = await req.json();
  const status = await prisma.$transaction(async (tx) => {
    const s = await tx.section.findUnique({ where: { id: sectionId } });
    if (!s) return 404;
    if (s.enrolled >= s.capacity) return 409;
    await tx.section.update({ where: { id: sectionId }, data: { enrolled: { increment: 1 } } });
    return 200;
  });
  return Response.json({ status }, { status });
}
export async function DELETE(req: Request) {
  await ready();
  const { sectionId } = await req.json();
  await prisma.section.updateMany({ where: { id: sectionId, enrolled: { gt: 0 } }, data: { enrolled: { decrement: 1 } } });
  return Response.json({ ok: true });
}
